package com.javamaster.model;

import lombok.Data;

@Data
public class Player {

    private String login;
}
