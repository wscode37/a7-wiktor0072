package com.javamaster.model;

public enum GameStatus {
    NEW, IN_PROGRESS, FINISHED
}
